 function p=dfy(x, y)
     p = 2*x*(x*y - x + 3/2) + 4*x*y*(x*y^2 - x + 9/4) + ...
        6*x*y^2*(x*y^3 - x + 21/8);
 end